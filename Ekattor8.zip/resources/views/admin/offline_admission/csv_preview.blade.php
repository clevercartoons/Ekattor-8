<div>
	<img src="{{ asset('public/assets/csv_file/csv_file.jpg') }}" width="100%" >
</div>