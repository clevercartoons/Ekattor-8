<!-- Jquery Js -->
<script src="{{ asset('public/frontend/assets/js/jquery-3.6.1.min.js') }}"></script>
<!-- Bootstarp Js -->
<script src="{{ asset('public/frontend/assets/js/bootstrap.bundle.min.js') }}"></script>
<!-- Main Js -->
<script src="{{ asset('public/frontend/assets/js/custom.js') }}"></script>